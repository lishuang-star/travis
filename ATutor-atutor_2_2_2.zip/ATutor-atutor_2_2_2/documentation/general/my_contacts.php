<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate: 2006-07-01 18:04:33 -0400 (Sat, 01 Jul 2006) $'; ?>

<h2>My Contacts</h2>

<dl>
<dt>My Contacts</dt>
<dd>This is a list of people in your social network.  You can find others on the network by using the <strong>Search People</strong> tool, and you can request that you and they become contacts. When you find a person, click on the green plus sign (<img src="../../mods/_standard/social/images/plus_icon.gif" alt="plus">) to  make your request. To remove a person in your Contacts, click on the red X ( <img src="../../mods/_standard/social/images/b_drop.png" alt="ex">). View a contact's profile from My Contacts by clicking on their thumbnail photo or their name. </dd>
</dl>
<?php require('../common/body_footer.inc.php'); ?>
