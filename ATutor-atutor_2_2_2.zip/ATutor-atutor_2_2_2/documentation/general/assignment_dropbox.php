<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate: 2011-05-30 14:53:12 -0400 (Mon, 29 May 2011) $'; ?>

<h2>Assignment Dropbox</h2>
	<p>   Once the Assignment Dropbox has been turned on in Course Tools by the instructor, a link "Assignment Dropbox" is displayed either on the course home page or as a main navigation tab. The dropbox lists all the assignments that are assigned to the student viewing, up to the submission "cut off date." Students can upload or delete assignment files up until the "due date", after which assignment submissions are locked and can no longer be modified by the student. The Delete button is greyed out when the due date is passed. The Upload button remains available to students until the cut off date.
</p>

<?php require('../common/body_footer.inc.php'); ?>
