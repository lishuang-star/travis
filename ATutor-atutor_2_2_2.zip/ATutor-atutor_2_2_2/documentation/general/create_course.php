<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Create Course</h2>

<p>Only Instructors may create courses,  though if enabled,  students can request instructor accounts by selecting the Create Course link. View the <a href="../instructor/creating_courses.php">Instructor Documentation</a> on creating courses.</p>

<?php require('../common/body_footer.inc.php'); ?>