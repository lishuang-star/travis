<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Browse Courses</h2>

<p>The Browse Courses page lists all  courses presently available on the ATutor system.</p>  

<p>If a course is Public, it may be accessed without logging in first. Protected and Private courses require that you be logged in. Private courses are available only to those who have been approved and enrolled in the course.</p>

<?php require('../common/body_footer.inc.php'); ?>