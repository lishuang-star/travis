<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Introduction</h2>
<p>Welcome to the ATutor General User documentation. The information found here is applicable to both instructors and students. Also see the the <a href="../instructor">Instructor Documentation</a> for details of other tools that might be used to author content while in a group environment. </p>


<?php require('../common/body_footer.inc.php'); ?>