<?php

$text = array();
$text['next_chapter'] = 'Prochain Chapitre';
$text['previous_chapter'] = 'Chapitre Précédent';
$text['page_not_translated'] = 'Cette section n\'a pas été encore traduite à votre langue demandée.';
$text['doc_user'] = 'User Documentatione';

?>