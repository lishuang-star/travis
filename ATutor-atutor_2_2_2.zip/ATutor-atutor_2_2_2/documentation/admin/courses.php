<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Courses</h2>
	<p>An administrator can create and manage courses, shared forums, and course categories without having to login as a course instructor.</p>

<?php require('../common/body_footer.inc.php'); ?>
