<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Forums</h2>
	<p>This section allows administrators to create regular course-specific forums as well as shared cross-course forums. A shared forum is available to all courses specified to use it, allowing users from different courses to communicate with eachother in one forum. Only administrators can create shared forums, though instructors or privileged users in any of the courses sharing a forum can manage its messages.</p>

<?php require('../common/body_footer.inc.php'); ?>