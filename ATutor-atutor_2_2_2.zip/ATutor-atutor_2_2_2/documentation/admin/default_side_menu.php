<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Default Side Menu</h2>

	<p>Administrators are able to set the side menu dropdowns for newly created courses by specifying side menu defaults. Instructors can alter these settings after a course is created by going to Properties under the Manage area.  For more information, see <a href="../instructor/side_menu.php">Side Menu</a> in the instructor help area.</p>

<?php require('../common/body_footer.inc.php'); ?>