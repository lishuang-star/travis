<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Email Users</h2>
	<p>The Email Users feature allows an administrator to send an email to all students, instructors, or both. Unconfirmed and Disabled accounts are not included in the mailing. The email address specified in the <a href="system_preferences.php">System Preferences</a> is used as the reply-to address for the email(s).</p>

<?php require('../common/body_footer.inc.php'); ?>