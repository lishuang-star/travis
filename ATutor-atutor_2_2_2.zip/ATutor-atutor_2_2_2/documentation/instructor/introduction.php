<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Introduction</h2>
	<p>Welcome to the ATutor Instructor Documentation!</p>

	<p>Most of the course management tools are found in the <em>Manage</em> section and are available to instructors and students with assigned privileges (assistants).</p>


<?php require('../common/body_footer.inc.php'); ?>
