<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Syndicated Feeds</h2>
	<p>Since version 1.5.2, System Administrators are able to add syndicated news feeds to the system, making them available to instructors to use in their courses. When available, instructors can display the news feeds in the side menu of their courses by using the <a href="side_menu.php">Side Menu</a> editor of Student Tools, under Manage section, and selecting a feed from the dropdowns.</p>

<?php require('../common/body_footer.inc.php'); ?>
