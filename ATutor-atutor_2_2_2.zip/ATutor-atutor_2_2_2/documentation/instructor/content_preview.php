<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Previewing Content</h2>
	<p>The Preview tab displays the content page as it looks with the formatting given.  This is how the content page will appear to a user, with custom HTML, Glossary Terms, Code, and colours.</p>
		

<?php require('../common/body_footer.inc.php'); ?>
