<?php require('../common/body_header.inc.php'); $lm = '$LastChangedDate$'; ?>

<h2>Editing &amp; Deleting Backups</h2>
	<p>Selecting a backup and using the <kbd>Delete</kbd> button will delete that backup.</p>

	<p>Use the <kbd>Edit</kbd> button to edit the description of a selected backup. This will not change the backup's contents.</p>

<?php require('../common/body_footer.inc.php'); ?>
